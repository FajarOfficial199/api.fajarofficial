module.exports = {
  instanav: require('./scraper/igdl'),
  tiktokSearchVideo: require('./scraper/tiktoksearch'),
  PlayStore: require('./scraper/PlayStore'),
  npmstalk: require('./scraper/npmstalk'),
  getServerStatus: require('./scraper/samp'),
  tiktokStalk: require('./scraper/tiktokstalk'),
  capcutdl: require('./scraper/capcutdl'),
  pinterest: require('./scraper/pinterest')
}